module.exports = function () {
  const { getWebpackConfig } = require('.')
  return getWebpackConfig()
}
