export default {
  css: ['~/assets/main.css'],
  modules: ['@nuxtjs/axios']
}
