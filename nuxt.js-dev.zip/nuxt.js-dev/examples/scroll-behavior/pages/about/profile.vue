<template>
  <div class="child">
    <h1>Profile</h1>
    <div class="spacer" style="width: 100%; height: 3000px; background: grey" />
  </div>
</template>

<script>
export default {
  transition: 'fade'
}
</script>
