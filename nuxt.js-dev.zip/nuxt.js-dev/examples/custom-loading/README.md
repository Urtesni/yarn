# Custom loading with Nuxt.js

https://nuxtjs.org/examples/custom-loading
