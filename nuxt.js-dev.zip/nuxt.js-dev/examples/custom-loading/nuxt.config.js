export default {
  loading: '~/components/loading.vue'
}
