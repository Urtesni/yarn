# A minimal Hello World Nuxt.js app

https://nuxtjs.org/examples
