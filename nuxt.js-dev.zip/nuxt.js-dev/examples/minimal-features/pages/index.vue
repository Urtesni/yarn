<template>
  <div>
    <h1>Welcome!</h1>
    <nuxt-link to="/about">
      About Page
    </nuxt-link>
  </div>
</template>

<script>
export default {
  head: {
    title: 'Home page'
  }
}
</script>
