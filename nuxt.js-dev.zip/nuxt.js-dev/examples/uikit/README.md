# Nuxt with  [UIKit](https://github.com/uikit/uikit)

> [UIkit](https://github.com/uikit/uikit) is a lightweight and modular front-end framework for developing fast and powerful web interfaces

Live demo: https://uikit.nuxtjs.org

Live edit: https://glitch.com/edit/#!/nuxt-uitkit
