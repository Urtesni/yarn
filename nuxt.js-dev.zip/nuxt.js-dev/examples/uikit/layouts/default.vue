<template>
  <div class="uk-container">
    <Nuxt />
  </div>
</template>
