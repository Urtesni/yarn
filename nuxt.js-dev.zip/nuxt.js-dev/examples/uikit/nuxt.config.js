export default {
  css: ['uikit/dist/css/uikit.css'],
  plugins: [
    { src: '~/plugins/uikit.js', ssr: false }
  ]
}
