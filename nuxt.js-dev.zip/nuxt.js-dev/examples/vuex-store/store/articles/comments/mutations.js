export default {
  add (state, title) {
    state.list.push(title)
  }
}
