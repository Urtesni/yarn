export default () => ({
  list: []
})
