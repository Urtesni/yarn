export default {
  todos (state) {
    return state.list
  }
}
