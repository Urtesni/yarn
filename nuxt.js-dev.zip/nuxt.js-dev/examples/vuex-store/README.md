# Nuxt with [Vuex](https://vuex.vuejs.org/) and store modules

> Vuex is a state management pattern + library for Vue.js applications. 

Read on Vuex modules [here](https://vuex.vuejs.org/guide/modules.html)

https://nuxtjs.org/guide/vuex-store#modules-files
