<template>
  <div>
    <img src="logo.png">
    <Nuxt />
  </div>
</template>

<style scoped>
img {
  position: fixed;
  top: 20px;
  right: 20px;
  z-index: 1000;
}
</style>
