# Nuxt layouts

https://nuxtjs.org/examples/layouts

Read more on Nuxt layouts [here](https://nuxtjs.org/guide/views#layouts)
