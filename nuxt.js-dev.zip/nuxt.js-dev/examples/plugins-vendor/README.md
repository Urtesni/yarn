# Using external modules and plugins with Nuxt.js

https://nuxtjs.org/examples/plugins
