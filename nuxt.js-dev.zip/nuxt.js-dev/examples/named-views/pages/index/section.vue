<template>
  <div>
    <h2>Section content</h2>
    <p>This page does not have left panel.</p>
  </div>
</template>

<script>
export default {
  name: 'Section'
}
</script>

<style scoped>

</style>
