<template>
  <div class="top">
    Main Top content!
  </div>
</template>

<script>
export default {
  name: 'MainTop'
}
</script>

<style scoped>
  .top {
    margin: auto;
    max-width: 420px;
    padding: 10px;
  }
</style>
