<template>
  <div>
    Child Left content!
  </div>
</template>

<script>
export default {
  name: 'ChildLeft'
}
</script>

<style scoped>

</style>
