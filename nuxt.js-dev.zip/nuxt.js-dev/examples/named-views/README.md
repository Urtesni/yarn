# Nuxt with named views
