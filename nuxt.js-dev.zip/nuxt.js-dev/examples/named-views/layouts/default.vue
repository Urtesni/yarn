<template>
  <div>
    <Nuxt name="top" />
    <Nuxt />
  </div>
</template>
