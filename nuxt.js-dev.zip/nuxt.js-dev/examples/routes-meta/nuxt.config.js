export default {
  router: {
    middleware: ['theme']
  },
  css: ['wingcss']
}
