# Routes meta with Nuxt.js

Demo: https://nuxt-routes-meta.glitch.me

Live edit: https://glitch.com/edit/#!/nuxt-routes-meta
