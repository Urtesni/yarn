# Nuxt with [Vue-ChartJS](https://vue-chartjs.org/)

> *Vue-chartjs* is a wrapper for [Chart.js](https://github.com/chartjs/Chart.js) in vue. You can easily create reuseable chart components.

Live demo: http://nuxt-vue-chartjs.surge.sh

[![Edit example-vue-chartjs](https://codesandbox.io/static/img/play-codesandbox.svg)](https://codesandbox.io/s/github/nuxt/nuxt.js/tree/dev/examples/vue-chartjs?fontsize=14&hidenavigation=1&theme=dark)
