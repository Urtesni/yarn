# Dynamic Layouts

https://nuxtjs.org/examples/layouts
