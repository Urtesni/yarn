# Nuxt with cookies

This demo showcases reading/updating cookies with Nuxt.js

https://nuxtjs.org/examples
