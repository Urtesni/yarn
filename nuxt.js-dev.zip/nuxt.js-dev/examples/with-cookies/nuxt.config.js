export default {
  head: {
    title: 'Nuxt-Cookies',
    meta: [
      { content: 'width=device-width,initial-scale=1', name: 'viewport' }
    ]
  },
  plugins: ['~/plugins/cookies']
}
