# Nuxt with static images

How to use static images with nuxt
