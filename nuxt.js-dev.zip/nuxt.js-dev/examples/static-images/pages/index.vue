<template>
  <div class="container">
    <img src="nuxt.png">
    <h2>Hello World.</h2>
    <p>
      <NuxtLink to="/about">
        About
      </NuxtLink>
    </p>
  </div>
</template>

<style scoped>
.container {
  font-family: sans-serif;
  margin-top: 200px;
  text-align: center;
}
</style>
