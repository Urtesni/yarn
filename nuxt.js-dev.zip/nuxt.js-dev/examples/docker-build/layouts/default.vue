<template>
  <div>
    <nuxt />
  </div>
</template>

<style>
</style>
