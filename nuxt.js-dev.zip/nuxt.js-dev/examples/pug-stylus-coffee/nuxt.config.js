require('coffeescript/register')
module.exports = require('./nuxt.config.coffee')
