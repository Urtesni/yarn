# Dynamic Components with Nuxt.js

Demo: https://dynamic-components.nuxtjs.org/

Video: https://www.youtube.com/watch?v=HzDea5-PFaw
