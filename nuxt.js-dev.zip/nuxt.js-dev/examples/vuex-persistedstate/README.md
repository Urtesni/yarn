# Nuxt with [Vuex](https://vuex.vuejs.org/) persisted state (localStorage)


Demo is using [vuex-persistedstate](https://github.com/robinvdvleuten/vuex-persistedstate) library
