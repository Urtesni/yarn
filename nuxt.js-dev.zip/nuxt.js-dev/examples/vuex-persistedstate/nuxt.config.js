export default {
  /*
  ** We set `spa` mode to have only client-side rendering
  */
  mode: 'spa'
}
