# Custom page loading with Nuxt.js

https://nuxtjs.org/examples/custom-page-loading

Use `loading: false` in page to manually call $loading.finish() and $loading.start() methods.
