<template>
  <div class="content">
    <h1 class="title">
      Custom CSS!
    </h1>
    <p>
      <NuxtLink to="/about" class="button is-medium is-primary hvr-float-shadow">
        I am a button
      </NuxtLink>
    </p>
    <p>
      <NuxtLink to="/about">
        About page
      </NuxtLink>
    </p>
  </div>
</template>
