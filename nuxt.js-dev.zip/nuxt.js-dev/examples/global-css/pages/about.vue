<template>
  <div class="content">
    <h1 class="title">
      Another Page
    </h1>
    <p>
      <NuxtLink to="/" class="button is-medium is-info hvr-wobble-vertical">
        Another button
      </NuxtLink>
    </p>
    <p>
      <NuxtLink to="/">
        Back home
      </NuxtLink>
    </p>
  </div>
</template>
