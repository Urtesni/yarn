# Global CSS with Nuxt.js

https://nuxtjs.org/examples/global-css
