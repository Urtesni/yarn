export default {
  css: ['~/assets/main.css']
}
