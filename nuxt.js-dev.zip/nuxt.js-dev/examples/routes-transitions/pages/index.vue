<template>
  <div class="container">
    <h1>Home page</h1>
    <p>
      <NuxtLink to="/about">
        About page
      </NuxtLink>
    </p>
    <p>
      <NuxtLink to="/users">
        Lists of users
      </NuxtLink>
    </p>
  </div>
</template>
