# Routes transitions with Nuxt.js

https://nuxtjs.org/examples/routes-transitions
