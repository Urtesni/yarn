<template>
  <div class="p-10">
    <h1 class="mb-6">
      Nuxt Tailwind CSS + Purgecss
    </h1>
    <Nuxt />
  </div>
</template>
