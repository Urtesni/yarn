# Nuxt in SPA mode

