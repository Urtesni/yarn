<template>
  <div>
    <h1>Welcome!</h1>
    <NuxtLink to="/about">
      About page
    </NuxtLink>
  </div>
</template>
