<template>
  <el-card class="box-card">
    <div slot="header" class="clearfix">
      <span>Element Example</span>
    </div>
    <div>
      <nuxt />
    </div>
  </el-card>
</template>
