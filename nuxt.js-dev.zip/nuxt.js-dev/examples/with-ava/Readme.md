# Nuxt with [Ava](https://github.com/avajs/ava)

> AVA is a test runner for Node.js with a concise API, detailed error output, embrace of new language features and process isolation that let you write tests more effectively. So you can ship more awesome code. rocket

## Testing your Nuxt.js Application

https://nuxtjs.org/examples/testing
