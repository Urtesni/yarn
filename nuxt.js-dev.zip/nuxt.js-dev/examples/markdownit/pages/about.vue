<template lang="md">
  # About Page!
  Current route is: {{ $route.name }}

  <NuxtLink to="/">Back home</NuxtLink>
</template>
