# Nuxt with Markdown 

> Convert Markdown file to HTML using markdown-it.

**See [Markdownit Module](https://github.com/nuxt-community/modules/tree/master/packages/markdownit) for easy integration with [Nuxt.js](https://nuxtjs.org).**
