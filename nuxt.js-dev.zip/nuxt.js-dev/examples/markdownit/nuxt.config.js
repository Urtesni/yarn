export default {
  modules: [
    '@nuxtjs/markdownit'
  ],
  plugins: [
    '~/plugins/md-it'
  ]
}
