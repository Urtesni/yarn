# Nuxt with i18n

https://nuxtjs.org/examples/i18n

https://github.com/kazupon/vue-i18n
