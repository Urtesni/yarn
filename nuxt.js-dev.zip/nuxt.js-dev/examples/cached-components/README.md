# Nuxt with Cached Components using lru-cache
