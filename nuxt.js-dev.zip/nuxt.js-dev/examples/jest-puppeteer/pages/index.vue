<template>
  <div>
    <h1>Welcome!</h1>
    <NuxtLink id="about-link" to="/about">
      About page
    </NuxtLink>
  </div>
</template>

<script>
export default {
  head: {
    title: 'Home page'
  }
}
</script>
