export default {
  /*
  ** Customize the progress bar color
  */
  loading: { color: '#3B8070' },
  modules: [
    'nuxt-buefy'
  ],
  router: {
    linkActiveClass: 'is-active'
  }
}
