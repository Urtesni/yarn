# Nuxt with [Buefy](https://buefy.github.io/)

> Buefy are lightweight UI components for Vue.js based on Bulma
