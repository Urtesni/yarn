export default {
  mode: 'universal'
}
