# Layout transitions with Nuxt.js

https://nuxtjs.org/examples/layout-transitions
