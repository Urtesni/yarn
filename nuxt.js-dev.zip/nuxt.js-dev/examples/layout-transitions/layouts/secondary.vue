<template>
  <div>
    <h1>Secondary Layout</h1>
    <Nuxt />
  </div>
</template>
