export default {
  css: ['~/assets/main.css'],
  layoutTransition: {
    name: 'layout',
    mode: 'out-in'
  }
}
