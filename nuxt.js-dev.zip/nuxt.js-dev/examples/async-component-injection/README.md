# Nuxt with advanced async components

See [here](https://vuejs.org/v2/guide/components.html#Advanced-Async-Components) for more details
