<template>
  <h1 style="text-align: center;">
    Article not found
  </h1>
</template>
