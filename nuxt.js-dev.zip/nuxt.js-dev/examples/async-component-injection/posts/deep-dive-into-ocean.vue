<template>
  <div>
    <h3 class="date">
      Jul 10, 2017
    </h3>
    <h1>Deep dive into the Ocean</h1>
    <div class="content">
      <img src="~/assets/img/swimmer.jpg">
      <h2>Subtitle #1</h2>
      <p>Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts. Separated they live in Bookmarksgrove right at the coast of the Semantics, a large language ocean. A small river named Duden flows by their place and supplies it with the necessary regelialia. It is a paradisematic country, in which roasted parts of sentences fly into your mouth. Even the all-powerful Pointing has no control about the blind texts it is an almost unorthographic life One day however a small line of blind text by the name of Lorem Ipsum decided to leave for the far World of Grammar.</p>
      <h2>Another subtitle</h2>
      <ul>
        <li>Vue.js</li>
        <li>Nuxt.js</li>
        <li>= &lt;3</li>
      </ul>
    </div>
  </div>
</template>
