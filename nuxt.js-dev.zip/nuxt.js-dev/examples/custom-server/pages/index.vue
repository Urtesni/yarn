<template>
  <p>
    Please look at <code>server.js</code> to see how to use <a href="https://nuxtjs.org">
      Nuxt.js
    </a> programmatically.
  </p>
</template>
