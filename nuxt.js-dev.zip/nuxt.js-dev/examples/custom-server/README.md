# Nuxt with custom [Express](https://expressjs.com/) Server

> Express ia a fast, unopinionated, minimalist web framework for Node.js
