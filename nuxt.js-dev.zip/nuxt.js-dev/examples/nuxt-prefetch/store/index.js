export const state = () => ({
  links: [
    'index',
    'agile',
    'brisk',
    'hot',
    'nimble',
    'quick',
    'rapid',
    'swift',
    'accelerated',
    'active',
    'dashing',
    'electric',
    'flashing',
    'fleet',
    'fleeting',
    'flying',
    'hurried',
    'racing',
    'ready',
    'snap',
    'winged'
  ]
})
