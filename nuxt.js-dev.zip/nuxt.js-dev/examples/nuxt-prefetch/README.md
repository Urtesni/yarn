# Example of Nuxt.js prefetching

Learn more at https://github.com/nuxt/nuxt.js/pull/4574
