<template>
  <div>
    <Nuxt />
    <Visits />
  </div>
</template>

<script>
import Visits from '~/components/Visits'

export default {
  components: { Visits }
}
</script>
