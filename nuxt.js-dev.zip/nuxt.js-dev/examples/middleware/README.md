# Middleware with Nuxt

## Demo
https://nuxtjs.org/examples/middleware

Read more Nuxt on middleware [here](https://nuxtjs.org/guide/routing#middleware)
