export default {
  router: {
    middleware: ['visits', 'user-agent']
  }
}
