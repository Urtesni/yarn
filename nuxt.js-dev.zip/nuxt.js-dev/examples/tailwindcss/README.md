# Nuxt.js with Tailwind CSS

See https://tailwindcss.com/docs/what-is-tailwind/

Demo: https://tailwindcss.nuxtjs.org
