export default {
  css: ['~/assets/css/tailwind.css']
}
