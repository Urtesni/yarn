<template>
  <!-- See https://tailwindcss.com/docs/container -->
  <div class="container mx-auto">
    <Nuxt />
    <a href="https://github.com/nuxt/nuxt.js/tree/dev/examples/tailwindcss" class="inline-flex items-center no-underline mt-4 rounded-full border border-grey-light bg-grey-lightest text-xs text-grey-darkest font-semibold p-2">
      <span class="inline-flex rounded-full mr-1">
        <svg class="h-4 w-4" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
          <path d="M12 .297c-6.63 0-12 5.373-12 12 0 5.303 3.438 9.8 8.205 11.385.6.113.82-.258.82-.577 0-.285-.01-1.04-.015-2.04-3.338.724-4.042-1.61-4.042-1.61C4.422 18.07 3.633 17.7 3.633 17.7c-1.087-.744.084-.73.084-.73 1.205.085 1.838 1.237 1.838 1.237 1.07 1.835 2.81 1.305 3.495.998.108-.776.417-1.305.76-1.605-2.665-.3-5.466-1.332-5.466-5.93 0-1.31.465-2.38 1.235-3.22-.136-.303-.54-1.523.104-3.176 0 0 1.005-.322 3.3 1.23.96-.267 1.98-.4 3-.405 1.02.005 2.04.137 3 .404 2.28-1.552 3.285-1.23 3.285-1.23.644 1.653.24 2.873.12 3.176.764.84 1.23 1.91 1.23 3.22 0 4.61-2.806 5.625-5.476 5.92.42.36.81 1.096.81 2.22 0 1.606-.015 2.896-.015 3.286 0 .315.21.69.824.57 4.8-1.574 8.236-6.074 8.236-11.37 0-6.626-5.373-12-12-12" />
        </svg>
      </span>
      <span>Source code</span>
    </a>
  </div>
</template>
