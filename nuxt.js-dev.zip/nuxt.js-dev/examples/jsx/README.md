# Nuxt with render Functions & JSX Example

## Documentation

Vue: https://vuejs.org/v2/guide/render-function.html

Also see [TSX example](https://github.com/nuxt/typescript/examples/tsx)
