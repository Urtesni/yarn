# Authenticated Routes with Nuxt and Express sessions

https://nuxtjs.org/examples/auth-routes
