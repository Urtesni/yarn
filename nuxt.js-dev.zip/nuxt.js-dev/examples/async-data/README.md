# Async data with Nuxt.js

https://nuxtjs.org/examples/async-data
