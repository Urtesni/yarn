# Nuxt with [Vue-class-component](https://github.com/vuejs/vue-class-component) library

> *vue-class-component* is an ECMAScript / TypeScript decorator for class-style Vue components.
