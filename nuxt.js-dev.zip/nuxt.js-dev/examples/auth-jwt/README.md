# Auth External API (JWT) with Nuxt.js

https://nuxtjs.org/examples/auth-external-jwt
