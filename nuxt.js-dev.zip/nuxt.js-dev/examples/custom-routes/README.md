# Custom Routes with Nuxt.js

https://nuxtjs.org/examples/custom-routes
