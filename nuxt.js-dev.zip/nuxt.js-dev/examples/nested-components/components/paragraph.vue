<template>
  <p class="p">
    <slot />
  </p>
</template>

<style scoped>
.p {
  font: 13px Helvetica, Arial;
  margin: 10px 0;
}
</style>
