# Nuxt with nested components example
