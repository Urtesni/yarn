<template>
  <p>Set port and host in <code>nuxt.config.js</code>.</p>
</template>
