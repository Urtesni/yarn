# Custom PORT and HOST in `nuxt.config.js` with Nuxt.js

https://nuxtjs.org/examples/custom-port-host
