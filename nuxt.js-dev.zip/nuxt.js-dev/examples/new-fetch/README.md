# New fetch() with Nuxt.js

Nuxt.js `v2.12` introduces a new hook called `fetch` in any of your Vue components.

See [live demo](https://nuxt-new-fetch.surge.sh) and [documentation](https://nuxtjs.org/api/pages-fetch).
