# Nuxt with [styled-vue](https://github.com/egoist/styled-vue)

> *styled-vue* allows to use dynamic styles in Vue single-file components.

See https://github.com/egoist/styled-vue
