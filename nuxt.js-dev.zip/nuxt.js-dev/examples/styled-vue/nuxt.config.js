module.exports = {
  modules: [
    'styled-vue/nuxt'
  ]
}
