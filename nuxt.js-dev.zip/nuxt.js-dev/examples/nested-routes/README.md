# Nested Routes with Nuxt.js

[https://nuxtjs.org/examples/nested-routes](https://nuxtjs.org/examples/nested-routes)
