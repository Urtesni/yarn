<template lang="pug">
  div
    p Hi from {{ name }}
    NuxtLink(to="/") Home Page
</template>

<script>
export default {
  asyncData () {
    return {
      name: process.static ? 'static' : (process.server ? 'server' : 'client')
    }
  },
  head: {
    title: 'About page'
  }
}
</script>
