# Nuxt.js with Pug

No further packages needed. It works out of the box.
