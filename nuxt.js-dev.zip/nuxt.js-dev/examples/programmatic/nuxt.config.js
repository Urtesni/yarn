export default {
  head: {
    title: 'Programmatic Works'
  }
}
