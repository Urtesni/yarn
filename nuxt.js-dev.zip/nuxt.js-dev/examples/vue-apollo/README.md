# Nuxt with [Vue-Apollo](https://vue-apollo.netlify.com/)

> *Vue-Apollo* is a Apollo/GraphQL integration for VueJS

Demo: https://nuxt-vue-apollo.now.sh/

https://github.com/nuxt-community/apollo-module

https://github.com/Akryum/vue-apollo
